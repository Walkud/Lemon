package com.example.test.bean.req;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class PostQueryReq {

    private String type;
    private int page;
    private int pageSize;
}

package com.example.test.bean.req;

import lombok.Data;

@Data
public class PostPartReq {
    private Integer num;
    private String msg;
    private String part;
    private String contentRequestBody;
    private Integer mapNum;
    private String mapMsg;
    private String mapPart;
    private String mapRequestBody;

}

package com.example.test.bean.res;

import lombok.Data;

@Data
public class ServerTime {

    private long time;

    public ServerTime() {
        time = System.currentTimeMillis();
    }
}

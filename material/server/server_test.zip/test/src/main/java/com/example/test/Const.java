package com.example.test;

public class Const {

    /**
     * 接口处理正常
     */
    public static final int CODE_SUCCESS = 0;
    /**
     * 接口处理异常结果
     */
    public static final int CODE_ERROR = 999;

}

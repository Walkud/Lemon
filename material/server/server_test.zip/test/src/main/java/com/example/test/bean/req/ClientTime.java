package com.example.test.bean.req;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ClientTime {

    private Long time;
    private Long createTime;
}

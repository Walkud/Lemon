package com.example.test.controller;

import com.example.test.Const;
import com.example.test.bean.*;
import com.example.test.bean.req.ClientTime;
import com.example.test.bean.req.PostQueryReq;
import com.example.test.bean.req.ReqBody;
import com.example.test.bean.res.Item;
import com.example.test.bean.res.ServerTime;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/lemon/")
@Slf4j
public class LemonController {

    private final Logger logger = LoggerFactory.getLogger(LemonController.class);
    private final long sleepTime = 3000;

    @Autowired
    private HttpServletRequest request;

    @GetMapping(path = "getServerTime")
    public BaseResult<ServerTime> getServerTime(){
        return new BaseResult<>(Const.CODE_SUCCESS,"",new ServerTime());
    }

    @GetMapping(path = "commitClientTime")
    public BaseResult<ServerTime> commitClientTime(ClientTime clientTime){
        System.out.println("clientTime:"+clientTime.toString());
        return new BaseResult<>(Const.CODE_SUCCESS,"OK",null);
    }

    @PostMapping(path = "post/query")
    public BaseResult<List<Item>> postQuery(PostQueryReq postQueryReq){

        Enumeration<String> headerNames = request.getHeaderNames();
        if(headerNames != null){
            StringBuilder sb = new StringBuilder();
            while(headerNames.hasMoreElements()){
               String headerName =  headerNames.nextElement();
               String value =  request.getHeader(headerName);
                sb.append(headerName);
                sb.append(":");
                sb.append(value);
                sb.append("\n");
            }
            System.out.println("postQuery headers:\n"+ sb +"\n\n");
        }



        int page = postQueryReq.getPage();
        int pageSize = postQueryReq.getPageSize();

        int idBase = (page-1)* pageSize;

        List<Item> itemList = new ArrayList<>();
        for(int i=0;i<pageSize;i++){
            int id = idBase+i +1;
            itemList.add(new Item(String.valueOf(id)));
        }

        try {
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return new BaseResult<>(Const.CODE_SUCCESS,"OK",itemList);
    }

    @PostMapping(path = "post/body")
    public BaseResult<List<Item>> postBody(@RequestBody ReqBody reqBody){
        System.out.println("ReqBody:"+reqBody.toString());
        return new BaseResult<>(Const.CODE_SUCCESS,"OK",null);
    }

    @PostMapping(path = "post/part")
    public BaseResult<Void> postPart(@RequestParam Map<String,String> map,
                                     @RequestParam("partFile") MultipartFile partFile,
                                     @RequestParam("mapFile") MultipartFile mapFile,
                                     HttpServletRequest request){
        Enumeration<String> headers = request.getHeaderNames();
        while(headers.hasMoreElements()){
            String name = headers.nextElement();
            String value = request.getHeader(name);
            logger.info("name={},value={}",name,value);
        }
        logger.info("postPart info:postPartReq={},partFileSize={},mapFileSize={}",map,partFile.getSize(),mapFile.getSize());

        try {
            logger.info("partFile:\n{}",new String(partFile.getBytes()));
            logger.info("mapFile:\n{}",new String(mapFile.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return new BaseResult<>(Const.CODE_SUCCESS,"OK",null);
    }

    @PostMapping(path = "post/queryGzipData")
    public BaseResult<List<Item>> queryGzipData(){
        System.out.println("queryGzipData");

        int page =2;
        int pageSize = 10;
        int idBase = (page-1)* pageSize;

        List<Item> itemList = new ArrayList<>();
        for(int i=0;i<200;i++){
            int id = idBase+i +1;
            itemList.add(new Item(String.valueOf(id)));
        }

        return new BaseResult<>(Const.CODE_SUCCESS,"OK",itemList);
    }

}
